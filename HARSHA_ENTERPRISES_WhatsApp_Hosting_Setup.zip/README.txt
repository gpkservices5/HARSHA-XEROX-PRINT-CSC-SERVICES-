HARSHA ENTERPRISES — XEROX AND PRINTING
LIVE SETUP STARTER

Included:
- index.html: branded responsive website with two WhatsApp destinations
- manifest.json: installable PWA metadata
- Android WebView starter source
- FREE_HOSTING_AND_QR_GUIDE.txt

WHATSAPP FLOW
The customer chooses files and the app opens a WhatsApp chat with a request summary. WhatsApp links cannot automatically attach the selected local files; the customer must attach them in the chat and tap Send.

FREE HOSTING
For a static demo, use GitHub Pages:
1. Sign in/create a GitHub account.
2. Create a public repository (e.g. harsha-enterprises-print).
3. Upload index.html and manifest.json to the repository root.
4. Open Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
5. Wait for the Pages URL, typically https://USERNAME.github.io/REPOSITORY/.
6. Open that URL on a phone and test before printing a QR code.
Do not upload customer documents to the public repository.

REAL SHARED UPLOADS + STATUS
Static hosting alone cannot receive/store documents securely or synchronize order status. A production version needs a backend (for example Firebase/Supabase or a small server), authentication/admin access, private file storage, upload limits, file validation, retention/deletion rules and a shop-side dashboard. This package does not configure an account or deploy a backend. Do not use public cloud folders for sensitive identity documents.

QR CODE
Only generate the final QR after the app has a stable public HTTPS URL. Then encode that exact URL using a QR generator or create a QR image locally. Test by scanning with multiple phones.

ANDROID APK
The Android wrapper source is included. After hosting:
1. Open android-wrapper in Android Studio.
2. In app/src/main/java/com/harshaenterprises/printing/MainActivity.java replace APP_URL with the final HTTPS URL.
3. Build > Build APK(s), test the APK on a device, then build a signed release APK for distribution.
A compiled APK is not included in this package.

Security: Avoid collecting Aadhaar, PAN, bank statements or other sensitive documents until a secure, private upload and deletion process is configured.
